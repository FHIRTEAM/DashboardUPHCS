const db = require('../db');

// 🚀 JS-level deduplication helper
function dedupeRecords(records, keyGen) {
  const seen = new Set();
  return records.filter(record => {
    const key = keyGen(record);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

// 🧬 Observations
async function insertObservations(observations) {
  if (!observations.length) return;

  const deduped = dedupeRecords(observations, o =>
    `${o.patient_id}_${o.code}_${o.effectiveDateTime}`
  );

  const values = deduped.map(o => [
    o.id, o.patient_id, o.code, o.display, o.value_numeric,
    o.value_string, o.unit, o.effectiveDateTime, o.source
  ]);

  const sql = `
    INSERT IGNORE INTO observations 
    (id, patient_id, code, display, value_numeric, value_string, unit, effectiveDateTime, source)
    VALUES ?
  `;

  await db.query(sql, [values]);
}

// 💉 Conditions
async function insertConditions(conditions) {
  if (!conditions.length) return;

  const deduped = dedupeRecords(conditions, c =>
    `${c.patient_id}_${c.code}_${c.effectiveDateTime}`
  );

  const values = deduped.map(c => [
    c.id, c.patient_id, c.code, c.display, c.clinical_status,
    c.effectiveDateTime, c.source
  ]);

  const sql = `
    INSERT IGNORE INTO conditions 
    (id, patient_id, code, display, clinical_status, effectiveDateTime, source)
    VALUES ?
  `;

  await db.query(sql, [values]);
}

// 🏥 Encounters
async function insertEncounters(encounters) {
  if (!encounters.length) return;

  const deduped = dedupeRecords(encounters, e =>
    `${e.patient_id}_${e.date}_${e.admission_reason}`
  );

  const values = deduped.map(e => [
    e.id, e.patient_id, e.class_code, e.class_display,
    e.type_code, e.type_display, e.date, e.admission_reason, e.source
  ]);

  const sql = `
    INSERT IGNORE INTO encounters 
    (id, patient_id, class_code, class_display, type_code, type_display, date, admission_reason, source)
    VALUES ?
  `;

  await db.query(sql, [values]);
}

// 👤 Patients with hospital location logic
async function insertPatient(patient) {
  if (!patient || !patient.id) return;

  let location_id = null;

  if (patient.city && patient.state && patient.postal_code) {
    const [existing] = await db.query(
      `SELECT id FROM hospital_locations WHERE city = ? AND state = ? AND postal_code = ?`,
      [patient.city, patient.state, patient.postal_code]
    );

    if (existing.length > 0) {
      location_id = existing[0].id;
    } else {
      const hospitalName = `${patient.city} General Hospital`;
      const result = await db.execute(
        `INSERT INTO hospital_locations (city, state, postal_code, hospital_name, latitude, longitude)
         VALUES (?, ?, ?, ?, 0, 0)`,
        [patient.city, patient.state, patient.postal_code, hospitalName]
      );
      location_id = result[0].insertId;
    }
  }

  const sql = `
    INSERT INTO patients 
    (patient_id, given_name, family_name, birth_date, gender, city, state, postal_code, location_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE 
      given_name = VALUES(given_name),
      family_name = VALUES(family_name),
      birth_date = VALUES(birth_date),
      gender = VALUES(gender),
      city = VALUES(city),
      state = VALUES(state),
      postal_code = VALUES(postal_code),
      location_id = VALUES(location_id)
  `;

  await db.execute(sql, [
    patient.id,
    patient.given_name,
    patient.family_name,
    patient.birth_date,
    patient.gender,
    patient.city,
    patient.state,
    patient.postal_code,
    location_id
  ]);
}

module.exports = {
  insertPatient,
  insertObservations,
  insertConditions,
  insertEncounters
};

// 🚀 JS-level deduplication helper
function dedupeRecords(records, keyGen) {
  const seen = new Set();
  return records.filter(record => {
    const key = keyGen(record);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

// 🧬 Observations
async function insertObservations(observations) {
  if (!observations.length) return;

  const deduped = dedupeRecords(observations, o =>
    `${o.patient_id}_${o.code}_${o.effectiveDateTime}`
  );

  const values = deduped.map(o => [
    o.id, o.patient_id, o.code, o.display, o.value_numeric,
    o.value_string, o.unit, o.effectiveDateTime, o.source
  ]);

  const sql = `
    INSERT IGNORE INTO observations 
    (id, patient_id, code, display, value_numeric, value_string, unit, effectiveDateTime, source)
    VALUES ?
  `;

  await db.query(sql, [values]);
}

// 💉 Conditions
async function insertConditions(conditions) {
  if (!conditions.length) return;

  const deduped = dedupeRecords(conditions, c =>
    `${c.patient_id}_${c.code}_${c.effectiveDateTime}`
  );

  const values = deduped.map(c => [
    c.id, c.patient_id, c.code, c.display, c.clinical_status,
    c.effectiveDateTime, c.source
  ]);

  const sql = `
    INSERT IGNORE INTO conditions 
    (id, patient_id, code, display, clinical_status, effectiveDateTime, source)
    VALUES ?
  `;

  await db.query(sql, [values]);
}

// 🏥 Encounters
async function insertEncounters(encounters) {
  if (!encounters.length) return;

  const deduped = dedupeRecords(encounters, e =>
    `${e.patient_id}_${e.date}_${e.admission_reason}`
  );

  const values = deduped.map(e => [
    e.id, e.patient_id, e.class_code, e.class_display,
    e.type_code, e.type_display, e.date, e.admission_reason, e.source
  ]);

  const sql = `
    INSERT IGNORE INTO encounters 
    (id, patient_id, class_code, class_display, type_code, type_display, date, admission_reason, source)
    VALUES ?
  `;

  await db.query(sql, [values]);
}

// 👤 Patients with hospital location logic
async function insertPatient(patient) {
  if (!patient || !patient.id) return;

  let location_id = null;

  if (patient.city && patient.state && patient.postal_code) {
    const [existing] = await db.query(
      `SELECT id FROM hospital_locations WHERE city = ? AND state = ? AND postal_code = ?`,
      [patient.city, patient.state, patient.postal_code]
    );

    if (existing.length > 0) {
      location_id = existing[0].id;
    } else {
      const hospitalName = `${patient.city} General Hospital`;
      const result = await db.execute(
        `INSERT INTO hospital_locations (city, state, postal_code, hospital_name, latitude, longitude)
         VALUES (?, ?, ?, ?, 0, 0)`,
        [patient.city, patient.state, patient.postal_code, hospitalName]
      );
      location_id = result[0].insertId;
    }
  }

  const sql = `
    INSERT INTO patients 
    (patient_id, given_name, family_name, birth_date, gender, city, state, postal_code, location_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE 
      given_name = VALUES(given_name),
      family_name = VALUES(family_name),
      birth_date = VALUES(birth_date),
      gender = VALUES(gender),
      city = VALUES(city),
      state = VALUES(state),
      postal_code = VALUES(postal_code),
      location_id = VALUES(location_id)
  `;

  await db.execute(sql, [
    patient.id,
    patient.given_name,
    patient.family_name,
    patient.birth_date,
    patient.gender,
    patient.city,
    patient.state,
    patient.postal_code,
    location_id
  ]);
}

module.exports = {
  insertPatient,
  insertObservations,
  insertConditions,
  insertEncounters
};
