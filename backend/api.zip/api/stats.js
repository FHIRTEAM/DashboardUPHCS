// backend/api/stats.js
const express = require('express');
const db = require('../db');
const router = express.Router();

// 1. Summary Stats
router.get('/summary', async (req, res) => {
  try {
    const [[{ count: patients }]] = await db.query(`SELECT COUNT(*) AS count FROM patients`);
    const [[{ count: observations }]] = await db.query(`SELECT COUNT(*) AS count FROM observations`);
    const [[{ count: conditions }]] = await db.query(`SELECT COUNT(*) AS count FROM conditions`);
    const [[{ count: encounters }]] = await db.query(`SELECT COUNT(*) AS count FROM encounters`);
    res.json({ patients, observations, conditions, encounters });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load summary stats.' });
  }
});

// 2. Average Age
router.get('/age', async (req, res) => {
  try {
    const [rows] = await db.query(`SELECT birth_date FROM patients WHERE birth_date IS NOT NULL`);
    const ages = rows.map(r => {
      const birthYear = new Date(r.birth_date).getFullYear();
      return new Date().getFullYear() - birthYear;
    });
    const avg = ages.length ? (ages.reduce((a, b) => a + b) / ages.length).toFixed(1) : 0;
    res.json({ averageAge: parseFloat(avg) });
  } catch (err) {
    res.status(500).json({ error: 'Failed to calculate average age.' });
  }
});

// 3. Gender Breakdown
router.get('/gender', async (req, res) => {
  try {
    const [rows] = await db.query(`SELECT gender, COUNT(*) AS count FROM patients GROUP BY gender`);
    const formatted = rows.map(r => ({ gender: r.gender || 'unknown', count: r.count }));
    res.json(formatted);
  } catch (err) {
    res.status(500).json({ error: 'Failed to load gender data.' });
  }
});

// 4. Chronic Conditions Frequency
// /routes/stats.js
router.get('/chronic', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT display AS \`condition\`, COUNT(*) AS count
  FROM conditions
  WHERE code IN ("44054006", "38341003", "233604007", "195967001", "55822004", "25064002")
  GROUP BY display
  ORDER BY count DESC
    `);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch chronic condition stats' });
  }
});


// Normalize long or inconsistent reasons
const REASON_LABELS_MAP = [
  { match: /humiliated or emotionally abused/i, label: "Abuse Screening" },
  { match: /adolescent depression screening/i, label: "Depression Screening" },
  { match: /urine drug screening/i, label: "Drug Screening" },
  { match: /fall risk/i, label: "Fall Risk" },
  { match: /xanax|overdose|drug|toxicity|withdrawal/i, label: "Drug Overdose" },
  { match: /\bchf\b|heart failure/i, label: "CHF" },
  { match: /shortness of breath|dyspnea|sob/i, label: "Shortness of Breath" },
  { match: /chest pain/i, label: "Chest Pain" },
  { match: /anemia|hemoglobin/i, label: "Anemia" },
  { match: /ams|altered mental/i, label: "AMS" },
  { match: /rib pain/i, label: "Rib Pain" },
  { match: /trauma|injury|fall/i, label: "Fall or Injury" }
];

// GET /api/stats/admissions
router.get('/admissions', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT 
        TRIM(COALESCE(admission_reason, '')) AS raw_reason,
        COUNT(*) AS count
      FROM encounters
      GROUP BY raw_reason
    `);

    const reasonCounts = {};

    for (const row of rows) {
      let label = row.raw_reason || 'Others';

      // Apply regex mapping if match is found
      for (const map of REASON_LABELS_MAP) {
        if (map.match.test(label)) {
          label = map.label;
          break;
        }
      }

      // Aggregate
      reasonCounts[label] = (reasonCounts[label] || 0) + row.count;
    }

    // Sort and limit to top 50
    const topReasons = Object.entries(reasonCounts)
      .map(([reason, count]) => ({ reason, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 50);

    res.json(topReasons);
  } catch (err) {
    console.error('❌ Error fetching admission reasons:', err);
    res.status(500).json({ error: 'Failed to fetch admission reasons' });
  }
});







module.exports = router;
