const express = require('express');
const router = express.Router();
const db = require('../db');

const CHRONIC_CONDITIONS = {
  "44054006": "Diabetes",
  "38341003": "Hypertension",
  "233604007": "COPD",
  "195967001": "Asthma",
  "55822004": "Depression",
  "25064002": "Heart Failure"
};

function getMonths2024() {
  const months = {};
  for (let i = 1; i <= 12; i++) {
    const month = `2024-${String(i).padStart(2, '0')}`;
    months[month] = 0;
  }
  return months;
}

function formatDay(dateInput) {
  try {
    const d = new Date(dateInput);
    if (isNaN(d.getTime())) return null;
    return d.toISOString().slice(0, 10); // e.g., '2024-03-15'
  } catch {
    return null;
  }
}

function formatMonth(dateInput) {
  try {
    const d = new Date(dateInput);
    if (isNaN(d.getTime())) return null;
    return d.toISOString().slice(0, 7); // e.g., '2024-03'
  } catch {
    return null;
  }
}

router.get('/:patientId', async (req, res) => {
  const patientId = req.params.patientId;

  try {
    let name = 'All Patients';
    const monthlyCounts = getMonths2024();
    const uniqueDays = new Set();

    let conditionQuery = `SELECT code, display FROM conditions`;
    let observationQuery = `SELECT effectiveDateTime AS date FROM observations`;
    const queryParams = [];

    if (patientId !== 'all') {
      const [[patient]] = await db.query(
        `SELECT CONCAT(given_name, ' ', family_name) AS name FROM patients WHERE patient_id = ?`,
        [patientId]
      );
      if (!patient) return res.status(404).json({ error: 'Patient not found' });

      name = patient.name;
      conditionQuery += ` WHERE patient_id = ?`;
      observationQuery += ` WHERE patient_id = ?`;
      queryParams.push(patientId);
    }

    const [conditions] = await db.query(conditionQuery, queryParams);
    const [observations] = await db.query(observationQuery, queryParams);

    const chronicSet = new Set();
    const comorbidSet = new Set();

    for (const cond of conditions) {
      const code = cond.code?.trim();
      const display = cond.display?.trim();
      const label = display || code || "Unknown";

      if (!code) continue;

      if (CHRONIC_CONDITIONS.hasOwnProperty(code)) {
        chronicSet.add(CHRONIC_CONDITIONS[code]);
      } else {
        comorbidSet.add(label.replace(/[\^]/g, ''));
      }
    }

    for (const { date } of observations) {
      const formattedDay = formatDay(date);
      const formattedMonth = formatMonth(date);

      if (
        formattedDay &&
        formattedMonth &&
        formattedMonth.startsWith("2024")
      ) {
        if (!uniqueDays.has(formattedDay)) {
          uniqueDays.add(formattedDay);
          monthlyCounts[formattedMonth] += 1;
        }
      }
    }

    const avgLengthOfStay = uniqueDays.size
      ? parseFloat((1).toFixed(1))
      : 0;

    res.json({
      patient_id: patientId,
      name,
      conditions: [...chronicSet],
      comorbidities: [...comorbidSet],
      monthly_visits: monthlyCounts,
      avg_length_of_stay: avgLengthOfStay
    });

  } catch (err) {
    console.error("❌ Error in /api/dashboard/:patientId", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
